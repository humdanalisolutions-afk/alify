@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0upload-to-github.ps1"
if errorlevel 1 (
  echo.
  echo Upload did not finish. Read the error above.
) else (
  echo.
  echo Check your GitHub images folder for the uploaded WebP files.
)
pause
