$ErrorActionPreference = 'Stop'
$repo = 'https://github.com/humdanalisolutions-afk/alify.git'
$source = Join-Path $PSScriptRoot 'assets\images'
$files = @(Get-ChildItem -LiteralPath $source -File -Filter 'Neon_Lines_*_1920.webp' -ErrorAction Stop)
if ($files.Count -ne 14) { throw "Expected 14 WebP images in $source. Found $($files.Count). Extract the whole ZIP first." }
if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    Write-Host 'Git for Windows is required: https://git-scm.com/downloads/win' -ForegroundColor Yellow
    throw 'Git command not found. Install Git for Windows, then run this file again.'
}
$work = Join-Path $env:TEMP ('alify-image-upload-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $work -Force | Out-Null
$clone = Join-Path $work 'alify'
Write-Host 'Cloning ALIFY main branch...'
& git clone --depth 1 --branch main $repo $clone
if ($LASTEXITCODE -ne 0) { throw 'Git clone failed. Check your network connection.' }
$dest = Join-Path $clone 'assets\images'
New-Item -ItemType Directory -Path $dest -Force | Out-Null
Copy-Item -LiteralPath $files.FullName -Destination $dest -Force
Push-Location $clone
try {
    & git add -- 'assets/images'
    if ($LASTEXITCODE -ne 0) { throw 'Git add failed.' }
    $changes = & git diff --cached --name-only
    if ($LASTEXITCODE -ne 0) { throw 'Could not check staged files.' }
    if (-not $changes) { Write-Host 'Images are already identical in the repository; nothing to commit.' -ForegroundColor Green; exit 0 }
    Write-Host "Staged $($changes.Count) changed files:"
    $changes | ForEach-Object { Write-Host "  $_" }
    & git -c 'user.name=humdanalisolutions-afk' -c 'user.email=317815948+humdanalisolutions-afk@users.noreply.github.com' commit -m 'Add 14 Neon Lines WebP background images'
    if ($LASTEXITCODE -ne 0) { throw 'Git commit failed.' }
    Write-Host 'Pushing to GitHub... You may be asked to sign in through a browser.'
    & git push origin main
    if ($LASTEXITCODE -ne 0) { throw 'Git push failed. Sign in to GitHub when prompted and try running the script again.' }
    Write-Host 'SUCCESS! All 14 WebP images are committed to assets/images on main.' -ForegroundColor Green
    Write-Host 'https://github.com/humdanalisolutions-afk/alify/tree/main/assets/images'
} finally { Pop-Location }
