ALIFY — 14 Neon Lines WebP images
================================

1. Download and extract ALIFY_14_WebP_GitHub_Uploader.zip using Windows Extract All.
2. Install Git for Windows if you don't have it: https://git-scm.com/downloads/win
3. Double-click upload-to-github.cmd inside the extracted folder.
4. If asked by Git Credential Manager, sign in to your GitHub account.
5. When it says SUCCESS, check:
   https://github.com/humdanalisolutions-afk/alify/tree/main/assets/images

The script clones the latest main branch, copies all 14 original WebP images,
commits them in one commit, and pushes to GitHub. It does not change custom
CSS, JavaScript, or vendor libraries. A local Git installation and an account
with repository write permission are required.

IMPORTANT: Read the script before running it, as with any executable download.
